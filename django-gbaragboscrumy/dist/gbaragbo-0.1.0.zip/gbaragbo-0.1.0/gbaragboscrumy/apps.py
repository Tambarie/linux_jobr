from django.apps import AppConfig


class GbaragboscrumyConfig(AppConfig):
    name = 'gbaragboscrumy'
